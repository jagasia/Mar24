package mla.mar_24_jdbc_template_1.model;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class BranchDao {
	private JdbcTemplate jdbcTemplate;
	
	public BranchDao() {}	
	
	public JdbcTemplate getJt() {
		return jdbcTemplate;
	}

	public void setJt(JdbcTemplate jt) {
		this.jdbcTemplate = jt;
	}

	public int create(Branch branch) {
		return jdbcTemplate.update("insert into Branch values (?,?,?)",branch.getBid(),branch.getBname(),branch.getBcity());
	}
	public List<Branch> read() {
		return jdbcTemplate.query("SELECT * FROM Branch", new BranchRowMapper());
	}
	public Branch read(String bid) {
		return jdbcTemplate.queryForObject("SELECT * FROM Branch WHERE bid=?", new BranchRowMapper(),bid);
	}
	public int update(Branch branch) {
		return jdbcTemplate.update("UPDATE Branch SET bname=?, bcity=? WHERE bid=?",branch.getBname(),branch.getBcity(),branch.getBid());
	}
	public int delete(String bid) {
		return jdbcTemplate.update("DELETE FROM Branch WHERE bid=?",bid);
	}
	
}
