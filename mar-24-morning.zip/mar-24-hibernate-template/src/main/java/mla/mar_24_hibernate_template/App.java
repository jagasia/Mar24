package mla.mar_24_hibernate_template;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mla.mar_24_hibernate_template.model.Branch;
import mla.mar_24_hibernate_template.model.BranchDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        BranchDao bdao= (BranchDao) ctx.getBean("bdao");
//        Branch branch=new Branch("B00018", "Tomorrow", "Chennai");
//        bdao.delete("B00018");
//        List<Branch> branches = bdao.read();
//        for(Branch b : branches)
//        	System.out.println(b);
        
        Branch branch = bdao.read("B00016");
        System.out.println(branch);
    }
}
