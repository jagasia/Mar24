package mla.mar_24_jdbc_dao_support.model;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class BranchDao extends JdbcDaoSupport
{
	public int create(Branch branch)
	{
		return getJdbcTemplate().update("INSERT INTO Branch VALUES(?,?,?)",branch.getBid(),branch.getBname(),branch.getBcity());
	}
	public List<Branch> read()
	{
		return getJdbcTemplate().query("SELECT * FROM Branch", new BranchRowMapper());
	}
	public Branch read(String bid)
	{	
		return getJdbcTemplate().queryForObject("SELECT * FROM Branch WHERE bid=?", new BranchRowMapper(),bid);
	}
	public int update(Branch branch)
	{
		return getJdbcTemplate().update("UPDATE Branch SET bname=?, bcity=? WHERE bid=?",branch.getBname(),branch.getBcity(),branch.getBid());
	}
	public int delete(String bid)
	{
		return getJdbcTemplate().update("DELETE FROM Branch WHERE bid=?",bid);
	}
}
