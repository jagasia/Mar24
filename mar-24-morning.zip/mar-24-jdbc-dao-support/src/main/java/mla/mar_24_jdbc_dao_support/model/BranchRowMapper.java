package mla.mar_24_jdbc_dao_support.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BranchRowMapper implements RowMapper<Branch>
{

	public Branch mapRow(ResultSet rs, int rowNum) throws SQLException {
		Branch branch=new Branch(rs.getString(1), rs.getString(2), rs.getString(3));
		return branch;
	}
	
}
