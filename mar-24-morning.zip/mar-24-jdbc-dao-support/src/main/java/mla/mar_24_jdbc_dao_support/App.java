package mla.mar_24_jdbc_dao_support;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mla.mar_24_jdbc_dao_support.model.Branch;
import mla.mar_24_jdbc_dao_support.model.BranchDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        BranchDao bdao=(BranchDao) ctx.getBean("bdao");
        List<Branch> branches = bdao.read();
        for(Branch b : branches)
        	System.out.println(b);
    }
}
