package mla.mar_24_hibernate_dao_support.model;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

public class BranchDao extends HibernateDaoSupport
{
	@Transactional
	public void create(Branch branch) {
		getHibernateTemplate().save(branch);
	}
	
	public List<Branch> read()
	{
		return getHibernateTemplate().loadAll(Branch.class);
	}
	
	public Branch read(String bid)
	{
		return getHibernateTemplate().get(Branch.class, bid);
	}
	
	@Transactional
	public void update(Branch branch)
	{
		getHibernateTemplate().update(branch);
	}
	
	@Transactional
	public void delete(String bid)
	{
		getHibernateTemplate().delete(read(bid));
	}
}
