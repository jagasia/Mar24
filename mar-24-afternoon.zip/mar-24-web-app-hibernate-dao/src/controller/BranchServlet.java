package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mla.mar_24_hibernate_dao_support.model.Branch;
import mla.mar_24_hibernate_dao_support.model.BranchDao;

/**
 * Servlet implementation class BranchServlet
 */
@WebServlet({ "/BranchServlet", "/branch" })
public class BranchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BranchServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String bid, bname, bcity, btn;
		bid=request.getParameter("bid");
		bname=request.getParameter("bname");
		bcity=request.getParameter("bcity");
		btn=request.getParameter("btn");
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		BranchDao bdao=(BranchDao) ctx.getBean("bdao");
		Branch branch=null;
		switch(btn)
		{
		case "Add":
				branch=new Branch(bid, bname, bcity);
				bdao.create(branch);
			break;
		case "Update":
				branch=new Branch(bid, bname, bcity);
				bdao.update(branch);
			break;
		case "Delete":
				bdao.delete(bid);
			break;
		}
		response.sendRedirect("index.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
